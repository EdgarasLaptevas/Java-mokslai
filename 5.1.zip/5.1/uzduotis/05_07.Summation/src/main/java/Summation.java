public class Summation {

    public static void main(String[] args) {
        int result = sum(4, 3, 6, 1);
        System.out.println("Sum: " + result);
    }

    public static int sum(int num1, int num2, int num3, int num4) {
        // write some code here
        return num1 + num2 + num3 + num4;
    }
}
