public class Room {

    private String code;
    private int seats;

    Room(String classCode, int numberOfSeats) {

        code = classCode;
        seats = numberOfSeats;
    }
}
