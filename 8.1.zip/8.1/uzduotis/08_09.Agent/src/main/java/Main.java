public class Main {

    public static void main(String[] args) {

        Agent n = new Agent("James", "Bond");

//        n.print();
//        n.toString();
        System.out.println(n);
    }
}
