public class Whistle {
    private String sound;

    public Whistle(String whistleSound) {
        sound = whistleSound;
    }

    public void sound() {
        System.out.println(sound);

    }
}
