
public interface TacoBox {

    int tacosRemaining();

    void eat();
}
